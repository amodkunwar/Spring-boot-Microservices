package com.example.demo.implementation;

import java.util.Objects;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.entity.User;
import com.example.demo.entity.UserEducationEntity;
import com.example.demo.model.UserEducationResponse;
import com.example.demo.model.UserRequest;
import com.example.demo.model.UserResponse;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;

@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RestTemplate restTemplate;

	String url = "http://USEREDUCATION/user/education/save";

	@Override
	public UserResponse saveUser(UserRequest userRequest) {
		User user = setUser(userRequest);
		user = userRepository.save(user);
		UserEducationEntity userEducationEntity = new UserEducationEntity();
		userEducationEntity.setEmail(user.getEmail());
		userEducationEntity.setPercentage(user.getPercentage());
		userEducationEntity.setQualification(user.getQualification());
		UserEducationResponse postForObject = restTemplate.postForObject(url, userEducationEntity,
				UserEducationResponse.class);
		UserResponse userResponse = null;
		if (Objects.nonNull(postForObject)) {
			userResponse = setUserResponse(user);
		}
		return userResponse;
	}

	private UserResponse setUserResponse(User user) {
		UserResponse userResponse = new UserResponse();
		userResponse.setEmail(user.getEmail());
		userResponse.setLocation(user.getLocation());
		userResponse.setMobile(user.getMobile());
		userResponse.setName(user.getName());
		userResponse.setPercentage(user.getPercentage());
		userResponse.setQualification(user.getQualification());
		return userResponse;
	}

	private User setUser(UserRequest userRequest) {
		User user = new User();
		user.setEmail(userRequest.getEmail());
		user.setLocation(userRequest.getLocation());
		user.setMobile(userRequest.getMobile());
		user.setName(userRequest.getName());
		user.setPercentage(userRequest.getPercentage());
		user.setQualification(userRequest.getQualification());
		return user;
	}

}
