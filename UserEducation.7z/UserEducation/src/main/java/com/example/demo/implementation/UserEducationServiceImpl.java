package com.example.demo.implementation;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.UserEducationEntity;
import com.example.demo.model.UserEducationRequest;
import com.example.demo.model.UserEducationResponse;
import com.example.demo.repository.UserEducationRepository;
import com.example.demo.service.UserEducationService;

@Service
@Transactional
public class UserEducationServiceImpl implements UserEducationService {

	@Autowired
	private UserEducationRepository userEducationRepository;

	@Override
	public UserEducationResponse saveUserEduction(UserEducationRequest userEducationRequest) {
		UserEducationEntity userEducationEntity = setuserEducation(userEducationRequest);
		userEducationRepository.save(userEducationEntity);
		return setUserEducationResponse(userEducationEntity);
	}

	private UserEducationResponse setUserEducationResponse(UserEducationEntity userEducationEntity) {
		UserEducationResponse userEducationResponse = new UserEducationResponse();
		userEducationResponse.setEmail(userEducationEntity.getEmail());
		userEducationResponse.setPercentage(userEducationEntity.getPercentage());
		userEducationResponse.setQualification(userEducationEntity.getQualification());
		return userEducationResponse;

	}

	private UserEducationEntity setuserEducation(UserEducationRequest userEducationRequest) {
		UserEducationEntity userEducationEntity = new UserEducationEntity();
		userEducationEntity.setEmail(userEducationRequest.getEmail());
		userEducationEntity.setPercentage(userEducationRequest.getPercentage());
		userEducationEntity.setQualification(userEducationRequest.getQualification());
		return userEducationEntity;
	}

}
