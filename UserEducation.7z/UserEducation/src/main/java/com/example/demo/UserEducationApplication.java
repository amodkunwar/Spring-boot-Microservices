package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.example.demo.entity.UserEducationEntity;
import com.example.demo.repository.UserEducationRepository;

@SpringBootApplication
@EnableEurekaClient
public class UserEducationApplication implements CommandLineRunner {

	@Autowired
	private UserEducationRepository userEducationRepository;

	public static void main(String[] args) {
		SpringApplication.run(UserEducationApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		UserEducationEntity userEducationEntity = new UserEducationEntity();
		userEducationEntity.setEmail("pramod@gmail.com");
		userEducationEntity.setPercentage("88");
		userEducationEntity.setQualification("B.tech");
		userEducationRepository.save(userEducationEntity);

	}

}
