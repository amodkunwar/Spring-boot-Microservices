package com.example.demo.service;

import com.example.demo.model.UserEducationRequest;
import com.example.demo.model.UserEducationResponse;

public interface UserEducationService {

	public UserEducationResponse saveUserEduction(UserEducationRequest userEducationRequest);

}